// Wait for the entire HTML document to be loaded and parsed
document.addEventListener('DOMContentLoaded', () => {

    // --- STATE MANAGEMENT ---
    // This object holds the application's data, similar to state in React.
    const state = {
        currentView: 'student', // 'student' or 'faculty'
        chatMessages: [], // Array to store chat messages
        selectedFacultyId: 1, // Default faculty ID for the portal
        // Sample faculty data. In a real app, this would come from a server.
        facultyData: [
            { id: 1, name: "Dr. Sarah Johnson", department: "Computer Science", cabin: "CS-201", contact: "+1-555-0101", currentLocation: "Lab A-204", lastPunchIn: "10:30 AM", isLocationShared: true, isDND: false, isPresent: true, expertise: ["Artificial Intelligence", "Machine Learning"] },
            { id: 2, name: "Prof. Michael Chen", department: "Mathematics", cabin: "Math-105", contact: "+1-555-0102", currentLocation: "Conference Room B", lastPunchIn: "11:15 AM", isLocationShared: false, isDND: false, isPresent: true, expertise: ["Calculus", "Linear Algebra"] },
            { id: 3, name: "Dr. Emily Rodriguez", department: "Physics", cabin: "Phy-301", contact: "+1-555-0103", currentLocation: "Physics Lab", lastPunchIn: "9:45 AM", isLocationShared: true, isDND: true, isPresent: true, expertise: ["Quantum Physics", "Thermodynamics"] },
            { id: 4, name: "Prof. David Wilson", department: "English Literature", cabin: "Eng-202", contact: "+1-555-0104", currentLocation: "Library", lastPunchIn: "2:20 PM", isLocationShared: true, isDND: false, isPresent: false, expertise: ["Victorian Literature", "Creative Writing"] }
        ],
        // Preset questions for chat suggestions
        presetQuestions: [
            "Where is Dr. Johnson?", "Where is Prof. Chen?", "Where is Dr. Rodriguez?", "Where is Prof. Wilson?",
            "Who is in Lab A-204?", "Who is in Physics Lab?", "Who is in Conference Room B?",
            "Is Dr. Johnson available?", "Is Prof. Chen available?", "Is Dr. Rodriguez available?",
            "Contact info for Dr. Johnson", "Mathematics department faculty", "Computer Science department faculty", "List all faculty"
        ]
    };

    // --- DOM ELEMENT SELECTORS ---
    // Getting references to all the HTML elements we need to interact with.
    const studentView = document.getElementById('student-view');
    const facultyView = document.getElementById('faculty-view');
    const studentViewBtn = document.getElementById('student-view-btn');
    const facultyViewBtn = document.getElementById('faculty-view-btn');
    const chatMessagesContainer = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const suggestionsBox = document.getElementById('suggestions-box');
    const facultyStatusList = document.getElementById('faculty-status-list');
    const facultySelector = document.getElementById('faculty-selector');
    const locationInput = document.getElementById('location-input');
    const shareLocationCheckbox = document.getElementById('share-location-checkbox');
    const dndCheckbox = document.getElementById('dnd-checkbox');
    const updateStatusBtn = document.getElementById('update-status-btn');
    const currentFacultyStatusContainer = document.getElementById('current-faculty-status');
    const presenceRadios = document.querySelectorAll('input[name="presence"]');
    const facultyControlsWrapper = document.getElementById('faculty-controls-wrapper');
    const quickActionButtons = document.querySelectorAll('.quick-action-btn');
    const notificationBox = document.getElementById('notification-box');

    // --- RENDER FUNCTIONS ---
    // These functions are responsible for updating the UI based on the current state.

    /**
     * Renders the chat messages to the screen.
     */
    const renderChatMessages = () => {
        chatMessagesContainer.innerHTML = ''; // Clear existing messages
        if (state.chatMessages.length === 0) {
            chatMessagesContainer.innerHTML = `
                <div class="text-center text-gray-500 mt-16">
                    <i data-lucide="message-circle" class="w-16 h-16 mx-auto mb-4 text-gray-300"></i>
                    <p class="font-medium">Start a conversation!</p>
                    <p class="text-sm mt-2">Try: "Where is Dr. Johnson?" or "Contact info for Prof. Chen"</p>
                </div>`;
        } else {
            state.chatMessages.forEach(msg => {
                const messageWrapper = document.createElement('div');
                const messageBubble = document.createElement('div');
                const pre = document.createElement('pre');

                messageWrapper.className = `mb-3 flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`;
                messageBubble.className = `inline-block p-3 rounded-lg max-w-sm ${msg.type === 'user' ? 'bg-blue-500 text-white user-message' : 'bg-white text-gray-800 border bot-message'}`;
                pre.textContent = msg.content;

                messageBubble.appendChild(pre);
                messageWrapper.appendChild(messageBubble);
                chatMessagesContainer.appendChild(messageWrapper);
            });
            // Scroll to the bottom of the chat window
            chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight;
        }
        lucide.createIcons(); // Re-render icons if any are in the messages
    };

    /**
     * Renders the faculty status cards in the student view.
     */
    const renderFacultyStatus = () => {
        facultyStatusList.innerHTML = ''; // Clear existing list
        state.facultyData.forEach(faculty => {
            const card = document.createElement('div');
            card.className = 'border rounded-lg p-4 transition hover:shadow-md hover:border-blue-300';

            let statusHTML = '';
            if (!faculty.isPresent) {
                statusHTML = `<p class="text-sm text-red-600 mt-1 font-medium flex items-center gap-1.5"><i data-lucide="x-circle" class="w-4 h-4"></i>Not on campus</p>`;
            } else if (faculty.isDND) {
                statusHTML = `<p class="text-sm text-orange-600 mt-1 font-medium flex items-center gap-1.5"><i data-lucide="shield-off" class="w-4 h-4"></i>Do Not Disturb</p>`;
            } else if (faculty.isLocationShared) {
                statusHTML = `<p class="text-sm text-green-600 mt-1 font-medium flex items-center gap-1.5"><i data-lucide="map-pin" class="w-4 h-4"></i>${faculty.currentLocation}</p>`;
            } else {
                statusHTML = `<p class="text-sm text-gray-500 mt-1 font-medium flex items-center gap-1.5"><i data-lucide="eye-off" class="w-4 h-4"></i>Location is Private</p>`;
            }

            card.innerHTML = `
                <div class="flex items-center justify-between mb-2">
                    <h4 class="font-semibold text-gray-800">${faculty.name}</h4>
                    <div class="flex gap-2 text-gray-400">
                        ${faculty.isPresent ? `<i data-lucide="user-check" class="w-5 h-5 text-green-500" title="On Campus"></i>` : `<i data-lucide="user-x" class="w-5 h-5 text-red-500" title="Not on Campus"></i>`}
                        ${faculty.isDND ? `<i data-lucide="shield" class="w-5 h-5 text-red-500" title="Do Not Disturb"></i>` : ''}
                        ${faculty.isLocationShared && faculty.isPresent ? `<i data-lucide="map-pin" class="w-5 h-5 text-green-500" title="Location Shared"></i>` : `<i data-lucide="map-pin" class="w-5 h-5 text-gray-400" title="Location Private"></i>`}
                    </div>
                </div>
                <p class="text-sm text-gray-600">${faculty.department}</p>
                <p class="text-sm text-gray-500">Cabin: ${faculty.cabin}</p>
                ${statusHTML}
            `;
            facultyStatusList.appendChild(card);
        });
        lucide.createIcons();
    };

    /**
     * Renders the suggestions dropdown based on user input.
     */
    const renderSuggestions = () => {
        const query = chatInput.value.toLowerCase();
        if (!query) {
            suggestionsBox.innerHTML = '';
            suggestionsBox.classList.add('hidden');
            return;
        }

        const filtered = state.presetQuestions.filter(q => q.toLowerCase().includes(query)).slice(0, 6);

        if (filtered.length > 0) {
            suggestionsBox.innerHTML = filtered.map(suggestion =>
                `<button class="suggestion-item w-full text-left px-4 py-2 hover:bg-gray-100 border-b border-gray-100 last:border-b-0 text-sm text-gray-700">${suggestion}</button>`
            ).join('');
            suggestionsBox.classList.remove('hidden');
        } else {
            suggestionsBox.classList.add('hidden');
        }
    };

    /**
     * Populates the faculty selector dropdown in the faculty portal.
     */
    const populateFacultySelector = () => {
        facultySelector.innerHTML = '';
        state.facultyData.forEach(f => {
            const option = document.createElement('option');
            option.value = f.id;
            option.textContent = f.name;
            facultySelector.appendChild(option);
        });
        facultySelector.value = state.selectedFacultyId;
    };

    /**
     * Updates the faculty portal form with the selected faculty's data.
     */
    const updateFacultyPortalForm = () => {
        const faculty = state.facultyData.find(f => f.id === state.selectedFacultyId);
        if (!faculty) return;

        locationInput.value = faculty.currentLocation;
        shareLocationCheckbox.checked = faculty.isLocationShared;
        dndCheckbox.checked = faculty.isDND;

        if (faculty.isPresent) {
            document.querySelector('input[name="presence"][value="present"]').checked = true;
            facultyControlsWrapper.style.display = 'block';
        } else {
            document.querySelector('input[name="presence"][value="absent"]').checked = true;
            facultyControlsWrapper.style.display = 'none';
        }
        renderCurrentFacultyStatus();
    };

    /**
     * Renders the "Current Status" box in the faculty portal.
     */
    const renderCurrentFacultyStatus = () => {
        const faculty = state.facultyData.find(f => f.id === state.selectedFacultyId);
        if (!faculty) return;

        let statusHTML = `
            <h3 class="font-semibold mb-2 text-gray-800">Current Status for ${faculty.name}</h3>
            <div class="text-sm text-gray-600 space-y-1">
                <p class="flex items-center gap-2">
                    ${faculty.isPresent ? '<i data-lucide="user-check" class="w-4 h-4 text-green-600"></i>Campus: <span class="font-medium text-green-700">Present</span>' : '<i data-lucide="user-x" class="w-4 h-4 text-red-600"></i>Campus: <span class="font-medium text-red-700">Absent</span>'}
                </p>`;

        if (faculty.isPresent) {
            statusHTML += `
                <p class="flex items-center gap-2"><i data-lucide="map-pin" class="w-4 h-4 text-gray-500"></i>Location: <span class="font-medium">${faculty.currentLocation || 'Not set'}</span></p>
                <p class="flex items-center gap-2"><i data-lucide="clock" class="w-4 h-4 text-gray-500"></i>Last Update: <span class="font-medium">${faculty.lastPunchIn || 'Never'}</span></p>
                <p class="flex items-center gap-2"><i data-lucide="eye" class="w-4 h-4 text-gray-500"></i>Visibility: <span class="font-medium">${faculty.isLocationShared ? 'Public' : 'Private'}</span></p>
                <p class="flex items-center gap-2"><i data-lucide="shield" class="w-4 h-4 text-gray-500"></i>DND Mode: <span class="font-medium">${faculty.isDND ? 'Enabled' : 'Disabled'}</span></p>
            `;
        }
        statusHTML += `</div>`;
        currentFacultyStatusContainer.innerHTML = statusHTML;
        lucide.createIcons();
    };


    // --- CHATBOT LOGIC ---
    /**
     * Processes a user's query and returns a bot response.
     * @param {string} query - The user's input message.
     * @returns {string} The bot's response.
     */
    const processChatQuery = (query) => {
        const lowerQuery = query.toLowerCase().trim();
        let response = "";
        let faculty = null;

        // Specific query: "who is in..."
        if (lowerQuery.startsWith('who is in') || lowerQuery.startsWith("who's in")) {
            const locationQuery = lowerQuery.replace(/who is in |who's in /i, '').replace('?', '').trim();
            const facultyInLocation = state.facultyData.filter(f =>
                f.isPresent && f.isLocationShared && !f.isDND &&
                f.currentLocation.toLowerCase().includes(locationQuery)
            );
            if (facultyInLocation.length > 0) {
                response = `${facultyInLocation.map(f => f.name).join(', ')} is currently in ${facultyInLocation[0].currentLocation}.`;
            } else {
                response = `I couldn't find any available faculty in "${locationQuery}", or their location is private.`;
            }
            return response;
        }

        // Find faculty by name
        for (let f of state.facultyData) {
            const fullName = f.name.toLowerCase();
            const lastName = fullName.split(' ').slice(-1)[0];
            if (lowerQuery.includes(fullName) || lowerQuery.includes(lastName)) {
                faculty = f;
                break;
            }
        }

        if (faculty) {
            if (!faculty.isPresent) {
                response = `${faculty.name} is not on campus today.\n- Cabin: ${faculty.cabin}\n- Contact: ${faculty.contact}`;
            } else if (lowerQuery.includes('available')) {
                response = faculty.isDND
                    ? `${faculty.name} is in "Do Not Disturb" mode. You can try their cabin: ${faculty.cabin}.`
                    : `${faculty.name} is available on campus! Their last known location was ${faculty.currentLocation}.`;
            } else if (lowerQuery.includes('where') || lowerQuery.includes('location')) {
                if (faculty.isDND) response = `${faculty.name} is in "Do Not Disturb" mode.`;
                else if (faculty.isLocationShared) response = `${faculty.name} was last seen at ${faculty.currentLocation} (at ${faculty.lastPunchIn}).`;
                else response = `${faculty.name}'s location is private. Try their cabin: ${faculty.cabin}.`;
            } else if (lowerQuery.includes('contact')) {
                response = `Contact details for ${faculty.name}:\n- Phone: ${faculty.contact}\n- Cabin: ${faculty.cabin}`;
            } else { // General query about a faculty member
                response = `${faculty.name} (${faculty.department})\n- Cabin: ${faculty.cabin}\n- Contact: ${faculty.contact}`;
                if (faculty.isPresent) {
                    if (faculty.isDND) response += `\n- Status: Do Not Disturb`;
                    else if (faculty.isLocationShared) response += `\n- Location: ${faculty.currentLocation}`;
                    else response += `\n- Status: On campus (location private)`;
                } else {
                    response += `\n- Status: Not on campus`;
                }
            }
        } else if (lowerQuery.includes('list') || lowerQuery.includes('all faculty')) {
            const present = state.facultyData.filter(f => f.isPresent);
            const absent = state.facultyData.filter(f => !f.isPresent);
            response = "Faculty Status:\n\nOn Campus:\n" + (present.length > 0 ? present.map(f => `• ${f.name}`).join('\n') : "None");
            response += "\n\nNot on Campus:\n" + (absent.length > 0 ? absent.map(f => `• ${f.name}`).join('\n') : "None");
        } else if (lowerQuery.includes('help')) {
            response = `You can ask me things like:\n• "Where is Dr. Johnson?"\n• "Is Prof. Chen available?"\n• "Who is in the Physics Lab?"\n• "Contact info for Dr. Rodriguez"\n• "List all faculty"`;
        } else {
            response = `I'm sorry, I couldn't find that. Please ask about a specific faculty member or type "help".`;
        }
        return response;
    };


    // --- EVENT HANDLERS & LOGIC ---

    /**
     * Handles sending a chat message from the user.
     */
    const handleSendMessage = () => {
        const message = chatInput.value.trim();
        if (!message) return;

        // Add user message to state and render
        state.chatMessages.push({ type: 'user', content: message });
        renderChatMessages();

        // Get and add bot response
        const botResponse = processChatQuery(message);
        setTimeout(() => {
            state.chatMessages.push({ type: 'bot', content: botResponse });
            renderChatMessages();
        }, 500); // Simulate bot "thinking"

        // Reset input
        chatInput.value = '';
        suggestionsBox.classList.add('hidden');
    };

    /**
     * Shows a temporary notification message.
     * @param {string} message - The message to display.
     * @param {boolean} isError - If true, shows a red error notification.
     */
    const showNotification = (message, isError = false) => {
        notificationBox.textContent = message;
        notificationBox.classList.remove('bg-green-500', 'bg-red-500');
        notificationBox.classList.add(isError ? 'bg-red-500' : 'bg-green-500');
        notificationBox.classList.remove('opacity-0');
        setTimeout(() => {
            notificationBox.classList.add('opacity-0');
        }, 3000);
    };

    /**
     * Handles updating a faculty member's status from the portal.
     */
    const handleUpdateStatus = () => {
        const faculty = state.facultyData.find(f => f.id === state.selectedFacultyId);
        if (!faculty) return;

        const isPresent = document.querySelector('input[name="presence"]:checked').value === 'present';

        if (isPresent && !locationInput.value.trim()) {
            showNotification('Please enter a location before updating.', true);
            return;
        }

        // Update the faculty data in our state
        faculty.isPresent = isPresent;
        if (isPresent) {
            faculty.currentLocation = locationInput.value;
            faculty.isLocationShared = shareLocationCheckbox.checked;
            faculty.isDND = dndCheckbox.checked;
            faculty.lastPunchIn = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        // Re-render the UI to reflect the changes
        renderFacultyStatus();
        renderCurrentFacultyStatus();
        showNotification('Status updated successfully!');
    };

    // --- EVENT LISTENERS ---

    // Switch between Student and Faculty views
    studentViewBtn.addEventListener('click', () => {
        state.currentView = 'student';
        studentView.classList.remove('hidden');
        facultyView.classList.add('hidden');
        studentViewBtn.classList.replace('bg-gray-100', 'bg-blue-500');
        studentViewBtn.classList.replace('text-gray-700', 'text-white');
        facultyViewBtn.classList.replace('bg-green-500', 'bg-gray-100');
        facultyViewBtn.classList.replace('text-white', 'text-gray-700');
    });

    facultyViewBtn.addEventListener('click', () => {
        state.currentView = 'faculty';
        facultyView.classList.remove('hidden');
        studentView.classList.add('hidden');
        facultyViewBtn.classList.replace('bg-gray-100', 'bg-green-500');
        facultyViewBtn.classList.replace('text-gray-700', 'text-white');
        studentViewBtn.classList.replace('bg-blue-500', 'bg-gray-100');
        studentViewBtn.classList.replace('text-white', 'text-gray-700');
    });

    // Chat functionality
    sendBtn.addEventListener('click', handleSendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSendMessage();
        }
    });
    chatInput.addEventListener('keyup', renderSuggestions);
    chatInput.addEventListener('focus', renderSuggestions);
    document.addEventListener('click', (e) => {
        if (!suggestionsBox.contains(e.target) && e.target !== chatInput) {
            suggestionsBox.classList.add('hidden');
        }
    });

    // Clicking on a suggestion
    suggestionsBox.addEventListener('click', (e) => {
        if (e.target.classList.contains('suggestion-item')) {
            chatInput.value = e.target.textContent;
            suggestionsBox.classList.add('hidden');
            chatInput.focus();
        }
    });

    // Quick action buttons
    quickActionButtons.forEach(button => {
        button.addEventListener('click', () => {
            chatInput.value = button.dataset.query;
            handleSendMessage();
        });
    });

    // Faculty portal functionality
    facultySelector.addEventListener('change', (e) => {
        state.selectedFacultyId = parseInt(e.target.value);
        updateFacultyPortalForm();
    });

    presenceRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            if (e.target.value === 'present') {
                facultyControlsWrapper.style.display = 'block';
            } else {
                facultyControlsWrapper.style.display = 'none';
            }
        });
    });

    updateStatusBtn.addEventListener('click', handleUpdateStatus);


    // --- INITIALIZATION ---
    /**
     * This function runs once when the script loads to set up the application.
     */
    const initialize = () => {
        renderChatMessages();
        renderFacultyStatus();
        populateFacultySelector();
        updateFacultyPortalForm();
        lucide.createIcons(); // Initial icon rendering
    };

    initialize(); // Run the app
});